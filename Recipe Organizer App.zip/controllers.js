const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../models/database');

const secretKey = 'your_secret_key';

exports.signup = (req, res) => {
  const { username, password } = req.body;

  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) return res.status(500).send('Server error');

    db.run(`INSERT INTO users (username, password) VALUES (?, ?)`,
      [username, hashedPassword], (err) => {
        if (err) return res.status(500).send('User already exists');
        res.status(201).send('User registered');
      });
  });
};

exports.login = (req, res) => {
  const { username, password } = req.body;

  db.get(`SELECT * FROM users WHERE username = ?`, [username], (err, user) => {
    if (err || !user) return res.status(400).send('User not found');

    bcrypt.compare(password, user.password, (err, result) => {
      if (result) {
        const token = jwt.sign({ id: user.id }, secretKey);
        res.status(200).json({ token });
      } else {
        res.status(401).send('Invalid credentials');
      }
    });
  });
};
