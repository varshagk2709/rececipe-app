const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const recipeController = require('../controllers/recipeController');
const authMiddleware = require('../middleware/authMiddleware');

router.post('/signup', authController.signup);
router.post('/login', authController.login);

router.use(authMiddleware.verifyToken);

router.get('/recipes', recipeController.getRecipes);
router.post('/recipes', recipeController.addRecipe);
router.put('/recipes', recipeController.editRecipe);
router.delete('/recipes', recipeController.deleteRecipe);

module.exports = router;
