const db = require('../models/database');

exports.getRecipes = (req, res) => {
  const userId = req.user.id;

  db.all(`SELECT * FROM recipes WHERE user_id = ?`, [userId], (err, rows) => {
    if (err) return res.status(500).send('Error retrieving recipes');
    res.status(200).json(rows);
  });
};

exports.addRecipe = (req, res) => {
  const { title, category, instructions, image } = req.body;
  const userId = req.user.id;

  db.run(`INSERT INTO recipes (user_id, title, category, instructions, image) VALUES (?, ?, ?, ?, ?)`,
    [userId, title, category, instructions, image], function (err) {
      if (err) return res.status(500).send('Error adding recipe');
      res.status(201).json({ id: this.lastID });
    });
};

exports.editRecipe = (req, res) => {
  const { id, title, category, instructions, image } = req.body;
  const userId = req.user.id;

  db.run(`UPDATE recipes SET title = ?, category = ?, instructions = ?, image = ? WHERE id = ? AND user_id = ?`,
    [title, category, instructions, image, id, userId], function (err) {
      if (err) return res.status(500).send('Error updating recipe');
      if (this.changes === 0) return res.status(404).send('Recipe not found');
      res.status(200).send('Recipe updated');
    });
};

exports.deleteRecipe = (req, res) => {
  const { id } = req.body;
  const userId = req.user.id;

  db.run(`DELETE FROM recipes WHERE id = ? AND user_id = ?`,
    [id, userId], function (err) {
      if (err) return res.status(500).send('Error deleting recipe');
      if (this.changes === 0) return res.status(404).send('Recipe not found');
      res.status(200).send('Recipe deleted');
    });
};
